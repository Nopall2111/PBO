package Tugas3;

public interface GeometriObject {
    double getArea();
    double getPerimeter();
}
